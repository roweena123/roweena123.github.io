# Roweena's Portfolio

A simple responsive portfolio website made with HTML and CSS.

## Publish free with GitHub Pages
1. Sign in to GitHub.
2. Create a **public** repository named exactly `roweena123.github.io` (if your GitHub username is still `roweena123`).
3. Upload `index.html` to the root of the repository and commit the file.
4. Open the repository's **Settings → Pages**. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then Save if those options are shown.
5. Wait a few minutes, then open `https://roweena123.github.io`.

If your GitHub username is different, use `<your-username>.github.io` as the repository name and replace the URL accordingly.

## Before publishing
- Replace the LinkedIn homepage link with your own profile URL.
- Add your professional email and resume link if you want them public.
- Replace generic project links with each project's repository.
- Check that every project description accurately reflects your work.
